import React from 'react'

const MyPerformance = () => {
  return (
    <div>
        <h1>Prices</h1>
    </div>
  )
}

export default MyPerformance;